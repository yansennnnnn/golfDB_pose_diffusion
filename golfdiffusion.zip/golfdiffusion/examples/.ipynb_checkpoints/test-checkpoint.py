import os
from moviepy.editor import VideoFileClip

# 设置目标总帧数和帧率
TARGET_FRAMES = 30
TARGET_FPS = 16

def process_video(file_path):
    print(f"处理视频：{file_path}")
    clip = VideoFileClip(file_path)
    
    # 计算裁剪时长（前30%）
    original_duration = clip.duration
    trimmed_duration = original_duration * 0.5
    trimmed_clip = clip.subclip(0, trimmed_duration)
    
    # 将剪辑结果重新采样到目标帧数和帧率
    # 方法：重新设置fps，自动在导出时调整
    new_filename = os.path.splitext(file_path)[0] + "_trimmed.mp4"
    
    # 写入新视频（固定帧率16fps，并裁剪至30帧）
    trimmed_clip = trimmed_clip.set_fps(TARGET_FPS)

    # 目标持续时间 = 30帧 / 16fps = 1.875秒
    # 重新采样 clip 到 1.875秒（或使用 speedx 调速）
    final_clip = trimmed_clip.fx(VideoFileClip.speedx, 
                                 final_duration=30 / TARGET_FPS)
    
    final_clip.write_videofile(new_filename, fps=TARGET_FPS, codec="libx264", audio=False)
    clip.close()
    final_clip.close()

def main():
    for filename in os.listdir("."):
        if filename.lower().endswith(".mp4"):
            process_video(filename)

if __name__ == "__main__":
    main()
