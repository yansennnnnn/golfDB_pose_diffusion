LOG_NAME = "trainer"
LOG_LEVEL = "INFO"
